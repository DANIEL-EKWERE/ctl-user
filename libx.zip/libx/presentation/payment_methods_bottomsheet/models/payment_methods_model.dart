// TODO Implement this library.
import '../../../core/app_export.dart';

/// This class defines the variables used in the [payment_methods_bottomsheet],
/// and is typically used to hold data that is passed between different parts of the application.
class PaymentMethodsModel {}
