// TODO Implement this library.
import '../../../core/app_export.dart';

/// This class defines the variables used in the [your_orders_history_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class YourOrdersHistoryModel {}
