import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:ctluser/main.dart';

// For checking internet connectivity
abstract class NetworkInfoI {
  Future<bool> isConnected();

  Future<List<ConnectivityResult>> get connectivityResult;

  Stream<List<ConnectivityResult>> get onConnectivityChanged;
}

class NetworkInfo implements NetworkInfoI {
  Connectivity connectivity;

  static final NetworkInfo _networkInfo = NetworkInfo._internal(Connectivity());

  factory NetworkInfo() {
    return _networkInfo;
  }

  NetworkInfo._internal(this.connectivity) {
    connectivity = this.connectivity;
  }

  ///checks internet is connected or not
  ///returns [true] if internet is connected
  ///else it will return [false]
  @override
  Future<bool> isConnected() async {
    final result = await connectivityResult;
    return !result.contains(ConnectivityResult.none);
  }

  // to check type of internet connectivity
  @override
  Future<List<ConnectivityResult>> get connectivityResult async {
    return connectivity.checkConnectivity();
  }

  //check the type on internet connection on changed of internet connection
  @override
  Stream<List<ConnectivityResult>> get onConnectivityChanged =>
      connectivity.onConnectivityChanged;
}

abstract class Failure {}

// General failures
class ServerFailure extends Failure {}

class CacheFailure extends Failure {}

class NetworkFailure extends Failure {}

class ServerException implements Exception {}

class CacheException implements Exception {}

class NetworkException implements Exception {}

///can be used for throwing [NoInternetException]
class NoInternetException implements Exception {
  late String _message;

  NoInternetException([String message = 'NoInternetException Occurred']) {
    this._message = message;
  }

  @override
  String toString() {
    return _message;
  }
}
// import 'package:flutter/material.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:ctl_user/main.dart';

// // For checking internet connectivity
// abstract class NetworkInfoI {
//   Future<bool> isConnected();

//   Future<List<ConnectivityResult>> get connectivityResult;

//   Stream<List<ConnectivityResult>> get onConnectivityChanged;
// }

// class NetworkInfo implements NetworkInfoI {
//   Connectivity connectivity;

//   static final NetworkInfo _networkInfo = NetworkInfo._internal(Connectivity());

//   factory NetworkInfo() {
//     return _networkInfo;
//   }

//   NetworkInfo._internal(this.connectivity) {
//     connectivity = this.connectivity;
//   }

//   ///checks internet is connected or not
//   ///returns [true] if internet is connected
//   ///else it will return [false]
//   @override
//   Future<bool> isConnected() async {
//     final result = await connectivityResult;
//     return !result.contains(ConnectivityResult.none);
//   }

//   // to check type of internet connectivity
//   @override
//   Future<List<ConnectivityResult>> get connectivityResult async {
//     return connectivity.checkConnectivity();
//   }

//   //check the type on internet connection on changed of internet connection
//   @override
//   Stream<List<ConnectivityResult>> get onConnectivityChanged =>
//       connectivity.onConnectivityChanged;
// }

// abstract class Failure {}

// // General failures
// class ServerFailure extends Failure {}

// class CacheFailure extends Failure {}

// class NetworkFailure extends Failure {}

// class ServerException implements Exception {}

// class CacheException implements Exception {}

// class NetworkException implements Exception {}

// ///can be used for throwing [NoInternetException]
// class NoInternetException implements Exception {
//   late String _message;

//   NoInternetException([String message = 'NoInternetException Occurred']) {
//     this._message = message;
//   }

//   @override
//   String toString() {
//     return _message;
//   }
// }
